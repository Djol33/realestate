<?php
session_start();


require_once  'vendor/autoload.php';
require 'Router/Routes.php';

