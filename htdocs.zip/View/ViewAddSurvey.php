<?php

namespace App\View;

class ViewAddSurvey extends View
{
    public static function View()
    {
        require_once "public/html/addSurvey.html";
    }

}