<?php

namespace App\View;

class ViewGetAllApartmentsJS extends View
{
    public static function View()
    {
        require_once __DIR__."/public/html/allApartmentsJS.html";
    }
}