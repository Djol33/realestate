<?php

namespace App\View;

class ViewAllApartments extends View
{
    public static function View()
    {
        require_once __DIR__.'/public/html/allApartments.html';

    }
}