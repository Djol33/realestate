<?php

namespace App\View;

class ViewRegister extends View
{
    public static function View()
    {
        require_once 'public/html/register.html';
    }
}