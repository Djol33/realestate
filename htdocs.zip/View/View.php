<?php

namespace App\View;

abstract class View
{
    public abstract static function View();

}