<?php

namespace App\View;

class ViewAdminAddTypeObject extends View
{
    public static function View()
    {
        require_once "View/public/html/AddTypeObject.html";
    }
}