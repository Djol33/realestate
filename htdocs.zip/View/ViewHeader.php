<?php

namespace App\View;

class ViewHeader extends View
{
    public static function View()
    {
        require_once "public/html/header.html";
    }
}