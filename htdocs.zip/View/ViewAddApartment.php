<?php

namespace App\View;

class ViewAddApartment extends View
{
    public static function View()
    {
        require_once __DIR__.'/public/html/addApartment.html';
    }

}