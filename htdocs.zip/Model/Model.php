<?php

namespace App\Model;

abstract class Model
{
    abstract function Query();

}