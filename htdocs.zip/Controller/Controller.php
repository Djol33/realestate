<?php

namespace App\Controller;

abstract class Controller
{
    public abstract static function Page();

}