<?php

namespace App\Controller;

class Author extends Controller
{
    public static function Page()
    {


        echo "<html>
<head></head>
<body>
<p>Nemanja Djokovic 36/22</p>
<img src='images/autor2.jpg'/>
</body>
</html>";

    }

}