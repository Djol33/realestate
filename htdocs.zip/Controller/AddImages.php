<?php

namespace App\Controller;

class AddImages extends Controller
{
    public static function Page()
    {
        if(isset($_SESSION["id"])){
            if($_SERVER["REQUEST_METHOD"]=="POST"){

            }
        }
    }
}